#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
command -v pawncc >/dev/null 2>&1 || { echo "ERROR: pawncc not found. A compatible Linux Pawn compiler is required." >&2; exit 2; }
for f in "$ROOT/pawno/include/a_samp.inc" "$ROOT/pawno/include/TOTP.inc" "$ROOT/pawno/include/timerfix.inc" "$ROOT/gamemodes/mapping/new_interior.inc" "$ROOT/gamemodes/mapping/new_interior_new_version.inc" "$ROOT/gamemodes/mapping/new_exteriors.inc"; do
  [[ -f "$f" ]] || { echo "ERROR: missing required file: $f" >&2; exit 3; }
done
echo "Prerequisite file check passed. This does NOT prove the source compiles."
echo "Before compiling, set DB placeholders locally in gamemodes/main.pwn and do not share the edited source."
echo "A successful compile must produce gamemodes/gm.amx; then validate plugins and run server smoke tests."
