#!/usr/bin/env bash
# FlinRP SA-MP Linux plugin staging helper.
# Run from the extracted FlinRP root on a machine with curl, tar, unzip, and file.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
PLUGIN_DIR="$ROOT/plugins"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$PLUGIN_DIR"

fetch() {
  local url="$1" out="$2"
  echo "Downloading $(basename "$out")"
  curl --fail --location --retry 3 --connect-timeout 20 "$url" -o "$out"
}
extract_archive() {
  local archive="$1" dest="$2"
  mkdir -p "$dest"
  case "$archive" in
    *.zip) unzip -q "$archive" -d "$dest" ;;
    *.tar.gz|*.tgz) tar -xzf "$archive" -C "$dest" ;;
    *) echo "Unknown archive type: $archive" >&2; return 1 ;;
  esac
}
copy_so() {
  local search_root="$1" wanted="$2" dest_dir="$3" found
  found="$(find "$search_root" -type f -name "$wanted" -print -quit || true)"
  if [[ -z "$found" ]]; then
    echo "ERROR: $wanted not found in downloaded archive" >&2
    return 1
  fi
  cp -f "$found" "$dest_dir/$wanted"
  echo "Staged $wanted"
}
check_x86() {
  local f="$1" desc
  if command -v file >/dev/null 2>&1; then
    desc="$(file -b "$f")"
    echo "$f: $desc"
    if [[ "$desc" != *"ELF 32-bit"* || ( "$desc" != *"Intel 80386"* && "$desc" != *"i386"* && "$desc" != *"Intel 80386, version 1 (SYSV)"* ) ]]; then
      echo "WARNING: architecture check did not confirm 32-bit x86 for $f; verify with LimoHost before use." >&2
    fi
  fi
}

# Official upstream release assets; selected for classic 32-bit SA-MP Linux servers.
fetch "https://github.com/samp-incognito/samp-streamer-plugin/releases/download/v2.9.6/samp-streamer-plugin-2.9.6.zip" "$TMP/streamer.zip"
extract_archive "$TMP/streamer.zip" "$TMP/streamer"
copy_so "$TMP/streamer" streamer.so "$PLUGIN_DIR"

fetch "https://github.com/pBlueG/SA-MP-MySQL/releases/download/R41-4/mysql-R41-4-Debian-static.tar.gz" "$TMP/mysql.tar.gz"
extract_archive "$TMP/mysql.tar.gz" "$TMP/mysql"
MYSQL_FILE="$(find "$TMP/mysql" -type f \( -name mysql.so -o -name mysql_static.so \) -print -quit || true)"
if [[ -z "$MYSQL_FILE" ]]; then echo "ERROR: mysql.so/mysql_static.so not found" >&2; exit 1; fi
cp -f "$MYSQL_FILE" "$PLUGIN_DIR/$(basename "$MYSQL_FILE")"
MYSQL_PLUGIN="$(basename "$MYSQL_FILE")"
echo "Staged $MYSQL_PLUGIN"

fetch "https://github.com/katursis/Pawn.RakNet/releases/download/1.5.1/pawnraknet-1.5.1-linux.tar.gz" "$TMP/raknet.tar.gz"
extract_archive "$TMP/raknet.tar.gz" "$TMP/raknet"
copy_so "$TMP/raknet" pawnraknet.so "$PLUGIN_DIR"

fetch "https://github.com/Y-Less/sscanf/releases/download/v2.13.8/sscanf-2.13.8-linux.tar.gz" "$TMP/sscanf.tar.gz"
extract_archive "$TMP/sscanf.tar.gz" "$TMP/sscanf"
copy_so "$TMP/sscanf" sscanf.so "$PLUGIN_DIR"

fetch "https://github.com/lassir/bcrypt-samp/releases/download/v2.2.3/bcrypt-samp-v2.2.3-debian-7-x86.tar.gz" "$TMP/bcrypt.tar.gz"
extract_archive "$TMP/bcrypt.tar.gz" "$TMP/bcrypt"
copy_so "$TMP/bcrypt" bcrypt-samp.so "$PLUGIN_DIR"

fetch "https://github.com/katursis/Pawn.CMD/releases/download/3.3.6/pawncmd-3.3.6-linux.tar.gz" "$TMP/pawncmd.tar.gz"
extract_archive "$TMP/pawncmd.tar.gz" "$TMP/pawncmd"
copy_so "$TMP/pawncmd" pawncmd.so "$PLUGIN_DIR"

fetch "https://github.com/ziggi/rustext/releases/download/v2.0.11/rustext-2.0.11.zip" "$TMP/rustext.zip"
extract_archive "$TMP/rustext.zip" "$TMP/rustext"
copy_so "$TMP/rustext" rustext.so "$PLUGIN_DIR"

fetch "https://github.com/AmyrAhmady/samp-plugin-crashdetect/releases/download/v4.22/crashdetect-4.22-linux.tar.gz" "$TMP/crashdetect.tar.gz"
extract_archive "$TMP/crashdetect.tar.gz" "$TMP/crashdetect"
copy_so "$TMP/crashdetect" crashdetect.so "$PLUGIN_DIR"

# Keep log-plugin/log-core on the same v0.4 generation as this gamemode's bundled
# log-core.dll and the MySQL R41 family; do not mix with log-core v0.5 runtime.
fetch "https://github.com/maddinat0r/samp-log/releases/download/v0.4/log-plugin-0.4-Linux.tar.gz" "$TMP/log-plugin.tar.gz"
extract_archive "$TMP/log-plugin.tar.gz" "$TMP/log-plugin"
copy_so "$TMP/log-plugin" log-plugin.so "$PLUGIN_DIR"
fetch "https://github.com/maddinat0r/samp-log-core/releases/download/v0.4/samp-log-core-runtime-0.4-Linux.tar.gz" "$TMP/log-core.tar.gz"
extract_archive "$TMP/log-core.tar.gz" "$TMP/log-core"
LOGCORE_FILE="$(find "$TMP/log-core" -type f \( -name 'log-core.so' -o -name 'log-core2.so' \) -print -quit || true)"
if [[ -z "$LOGCORE_FILE" ]]; then echo "ERROR: log-core runtime library not found" >&2; exit 1; fi
cp -f "$LOGCORE_FILE" "$ROOT/$(basename "$LOGCORE_FILE")"
echo "Staged $(basename "$LOGCORE_FILE") in server root"

for f in "$PLUGIN_DIR"/*.so; do check_x86 "$f"; done
check_x86 "$ROOT/$(basename "$LOGCORE_FILE")"

# Update the candidate config to list only the staged plugins, in Linux syntax.
if [[ -f "$ROOT/server_limohost_candidate.cfg" ]]; then
  # Keep mandatory native providers visible. TOTP.so and timerfix.so are NOT staged
# by this script yet; config is intentionally marked incomplete until those
# exact native providers are obtained and verified.
sed -i "s/^plugins .*/plugins crashdetect.so log-plugin.so $MYSQL_PLUGIN streamer.so sscanf.so bcrypt-samp.so pawnraknet.so pawncmd.so rustext.so TOTP.so timerfix.so/" "$ROOT/server_limohost_candidate.cfg"
fi

cat > "$ROOT/LINUX_PLUGIN_STAGE_STATUS.txt" <<STATUS
Linux plugin staging attempt completed.
This script only downloads/stages plugin binaries; it does NOT compile main.pwn or fix the full SQL schema.
Review each 'file' output above and verify plugin startup on the actual LimoHost host before replacing the live server.
MySQL plugin filename staged: $MYSQL_PLUGIN
The source still needs its mysql_connect() host/user/password/database updated and a fresh gm.amx compiled.
STATUS

echo
echo "Plugin staging finished. Read LINUX_PLUGIN_STAGE_STATUS.txt."
echo "Do not upload until architecture checks and a server startup test pass."
