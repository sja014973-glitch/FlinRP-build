#!/usr/bin/env bash
# FlinRP reproducible Pawn compile helper for a normal Linux x86_64 build machine.
# Does not download or install SA-MP plugins and does not configure database credentials.
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
VERSION='3.10.10'
URL="https://github.com/pawn-lang/compiler/releases/download/v${VERSION}/pawnc-${VERSION}-linux.tar.gz"
SHA256='9bbb1df6e933318fce1fa61951e4196b70613c637a5a1d4c96937e147c18468d'
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
for tool in curl tar sha256sum; do command -v "$tool" >/dev/null || { echo "ERROR: required tool missing: $tool" >&2; exit 2; }; done
[[ -f "$ROOT/gamemodes/main.pwn" ]] || { echo 'ERROR: gamemodes/main.pwn missing' >&2; exit 3; }
[[ -d "$ROOT/pawno/include" ]] || { echo 'ERROR: pawno/include missing' >&2; exit 3; }
for f in \
  "$ROOT/pawno/include/a_samp.inc" \
  "$ROOT/pawno/include/a_mysql.inc" \
  "$ROOT/pawno/include/streamer.inc" \
  "$ROOT/pawno/include/TOTP.inc" \
  "$ROOT/pawno/include/timerfix.inc" \
  "$ROOT/pawno/include/mapping/new_interior.inc" \
  "$ROOT/pawno/include/mapping/new_interior_new_version.inc" \
  "$ROOT/pawno/include/mapping/new_exteriors.inc"; do
  [[ -f "$f" ]] || { echo "ERROR: required include missing: $f" >&2; exit 4; }
done
printf 'Downloading official Pawn compiler %s...\n' "$VERSION"
curl -fL --retry 2 "$URL" -o "$WORK/pawnc.tar.gz"
printf '%s  %s\n' "$SHA256" "$WORK/pawnc.tar.gz" | sha256sum -c -
mkdir "$WORK/compiler"
tar -xzf "$WORK/pawnc.tar.gz" -C "$WORK/compiler"
PAWNCC="$(find "$WORK/compiler" -type f -name pawncc -perm -u+x | head -n1)"
[[ -n "$PAWNCC" ]] || { echo 'ERROR: pawncc not found in official archive' >&2; exit 5; }
# Keep compiler output in a temporary file first; do not overwrite any existing gm.amx on failure.
cd "$ROOT/gamemodes"
OUT="$WORK/gm.amx"
set +e
"$PAWNCC" main.pwn -i"$ROOT/pawno/include" -i"$ROOT/gamemodes" -o"$OUT"
RC=$?
set -e
if [[ $RC -ne 0 || ! -s "$OUT" ]]; then
  echo "ERROR: Pawn compile failed (exit $RC). Existing gamemodes/gm.amx was not changed." >&2
  exit 10
fi
cp "$OUT" "$ROOT/gamemodes/gm.amx.new"
echo 'Compile completed; output saved as gamemodes/gm.amx.new.'
echo 'This is only a compile check. It does NOT verify Linux plugins, DB schema, server startup, or player login.'
echo 'Do not replace gm.amx until the compiler output is reviewed and a backup exists.'
