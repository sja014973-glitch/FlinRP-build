FlinRP Linux Build Preparation — v9

Status: NOT upload-ready. v9 adds a reproducible compiler helper; it does not contain a freshly compiled AMX or Linux plugin binaries.

New file: BUILD_FLINRP_LINUX.sh
- Downloads the official Pawn compiler 3.10.10 Linux archive.
- Verifies the published SHA-256 before extracting it.
- Checks a subset of critical includes/maps, then attempts to compile gamemodes/main.pwn.
- Writes successful output to gamemodes/gm.amx.new and will not overwrite existing gm.amx on compile failure.

Run only on a Linux x86_64 machine with curl, tar and sha256sum. It is not a Termux ARM compiler fix. Compiler flags/include paths may need adjustment if the first run reports an include or option error.

Still unresolved: Linux .so plugin binaries and their compatibility, complete DB schema migration, and real server startup/login tests. The script does not download plugins, alter SQL, or set database credentials.

Security: keep this archive private because source files may contain database connection settings. Rotate any database password that was shared in chat. Never publish the PWN source or compiled AMX in a public repository.


V10 UPDATE:
- Added .github/workflows/build-flinrp-amx.yml for remote Linux Pawn compilation.
- Corrected prerequisite mapping include paths to pawno/include/mapping.
- Workflow has not been run from this package; compile success is not claimed.
